This is the free version of [Karna Jekyll Theme](http://webjeda.com/karna-full/)

Demo: [http://webjeda.com/karna](http://webjeda.com/karna)

## Installation
* Fork the repository
* Go to settings and set Github Pages source as master.
* Your new site should be ready.

For more themes visit - [https://jekyll-themes.com](https://jekyll-themes.com)