---
title: About
layout: post
permalink: /about/
---

Karna is a Jekyll theme created with pinterest like pins. It is a freemium theme.

For more themes visit - [**Webjeda Jekyll Themes**](https://blog.webjeda.com/jekyll-themes/){: target="_blank"}

For Jekyll tutorials visit - [**Webjeda**](https://blog.webjeda.com/){: target="_blank"}

Does the theme deserve a star?

<a class="github-button" href="https://github.com/sharu725/karna" data-style="mega" data-count-href="/sharu725/karna/stargazers" data-count-api="/repos/sharu725/karna#stargazers_count" data-count-aria-label="# stargazers on GitHub" aria-label="Star sharu725/karna on GitHub">Star</a>
<script async defer src="https://buttons.github.io/buttons.js"></script>

**Buy this theme**
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top" style="display: inline-block">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="sharu725@gmail.com">
<input type="hidden" name="lc" value="IN">
<input type="hidden" name="item_name" value="Karna Jekyll Theme">
<input type="hidden" name="item_number" value="karna">
<input type="hidden" name="button_subtype" value="services">
<input type="hidden" name="no_note" value="0">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest">
<table>
<tr><td><input type="hidden" name="on0" value="Add ons">Add ons</td></tr><tr><td><select name="os0">
	<option value="Theme + 3 months support">Theme + 3 months support $12.00 USD</option>
	<option value="Theme + Installation">Theme + Installation $18.00 USD</option>
	<option value="Theme + Extended 12 months support">Theme + Extended 12 months support $25.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="option_select0" value="Theme + 3 months support">
<input type="hidden" name="option_amount0" value="12.00">
<input type="hidden" name="option_select1" value="Theme + Installation">
<input type="hidden" name="option_amount1" value="18.00">
<input type="hidden" name="option_select2" value="Theme + Extended 12 months support">
<input type="hidden" name="option_amount2" value="25.00">
<input type="hidden" name="option_index" value="0">
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>


[**Demo**]({{site.full-version}}){: target="_blank"}

The premium theme includes the following:

1. Pagination
2. Share bar on hovering over the pins
3. Share bar in the article
4. Different page widths
5. Support